from sklearn.model_selection import train_test_split
import cv2, os
import numpy as np
from tensorflow.keras.utils import to_categorical

from keras.models import Sequential
from keras.layers import Dense,Activation,Flatten,Dropout
from keras.layers import Conv2D,MaxPooling2D
from keras.callbacks import ModelCheckpoint
from keras.optimizers import Adam

img_size=256    # most originals are 639x600

def get_images(categories):
    data=[]
    label=[]

    for category in categories:
        folder_path=os.path.join(data_path,category)
        img_names=os.listdir(folder_path)
            
        for img_name in img_names:
            img_path=os.path.join(folder_path,img_name)
            img=cv2.imread(img_path)
            try:
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  
                resized=cv2.resize(gray,(img_size,img_size))
                #resizing the image  into 256 x 256, since we need a fixed common size for all the images in the dataset
                data.append(resized)
                label.append(label_dict[category])
                #appending the image and the label(categorized) into the list (dataset)
            except Exception as e:
                print('Exception:',e)
                #if any exception raised, the exception will be printed here. And pass to the next image

    data=np.array(data)/255.0
    data=np.reshape(data,(data.shape[0],img_size,img_size,1))
    label=np.array(label)
    

    return data, label
    
##############
data_path='DATA/CADFINAL'
categories=os.listdir(data_path)
labels=[i for i in range(len(categories))]
label_dict = dict(zip(categories,labels)) 
print(label_dict, categories, labels)
data, label = get_images(categories)

nClasses = 4

def get_model(data):
    model=Sequential()

    model.add(Conv2D(img_size,(3,3),input_shape=data.shape[1:]))
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=(2,2)))

    model.add(Conv2D(64,(3,3)))
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=(2,2)))
    #The second convolution layer followed by Relu and MaxPooling layers

    model.add(Conv2D(32,(3,3)), name='last_conv')
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=(2,2)))
    #The third convolution layer followed by Relu and MaxPooling layers

    model.add(Flatten())
    #Flatten layer to stack the output convolutions from 3rd convolution layer
    model.add(Dropout(0.2))

    model.add(Dense(128,activation='relu'))
    model.add(Dropout(0.1))
    model.add(Dense(64,activation='relu'))

    model.add(Dense(nClasses, activation='softmax'))
    #The Final layer with two outputs for two categories

    model.compile(loss = 'categorical_crossentropy',
                  optimizer = Adam(learning_rate=0.001), 
                  metrics = ['accuracy'])
    print('[MODEL compiled]')
    return model
    
model = get_model(data)
new_label = to_categorical(label)
x_train,x_test,y_train,y_test = train_test_split(data,new_label,test_size=0.1)

print('[FITTING]')
history = model.fit(x_train, y_train, epochs=100, validation_split=0.25)   # callbacks=[print_every_n_epochs], ori=0.2

vaL_loss, val_accuracy= model.evaluate(x_test, y_test, verbose=0)
print("test loss:", vaL_loss,'%')
print("test accuracy:", val_accuracy,"%")